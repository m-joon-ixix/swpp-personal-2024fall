using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraController : MonoBehaviour
{
    public GameObject player;
    private Vector3[] offsets = { new Vector3(0, 4, -8), new Vector3(-4, 2, 6), new Vector3(4, 2, 6) };
    private float positionSmoothSpeed = 2.5f;
    private float rotationSmoothSpeed = 1.0f;
    public int mode; // for changing viewpoints

    // Start is called before the first frame update
    void Start()
    {
        mode = 1;
    }

    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Alpha1))
        {
            mode = 1;
        }

        if (Input.GetKeyDown(KeyCode.Alpha2))
        {
            mode = 2;
        }

        if (Input.GetKeyDown(KeyCode.Alpha3))
        {
            mode = 3;
        }
    }

    void LateUpdate()
    {
        Vector3 nextPosition = player.transform.position + player.transform.TransformDirection(offsets[mode - 1]);
        transform.position = Vector3.Lerp(transform.position, nextPosition, positionSmoothSpeed);

        // transform.LookAt(player.transform.position); => camera keeps shaking
        Quaternion nextRotation = Quaternion.LookRotation(player.transform.position - transform.position);
        transform.rotation = Quaternion.Slerp(transform.rotation, nextRotation, rotationSmoothSpeed);
    }
}
