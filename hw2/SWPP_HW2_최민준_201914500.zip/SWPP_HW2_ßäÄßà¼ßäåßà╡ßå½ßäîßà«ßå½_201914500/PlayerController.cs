using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    private float forwardForce = 9000.0f;
    private float maxSpeed = 20.0f;
    private float speedReduceRate = 0.0025f;
    private float turnSpeed = 45.0f;
    private float maxSteeringAngle = 30.0f;
    private float downforce = 250.0f;
    public float horizontalInput;
    public float forwardInput;

    public Transform wheelFL;
    public Transform wheelFR;
    public Transform wheelRL;
    public Transform wheelRR;
    private Rigidbody rb;

    private float wheelSpinAngle = 0.0f;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.centerOfMass = new Vector3(0, 0.25f, 0);
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        forwardInput = Input.GetAxis("Vertical");

        // rotate wheel from steering
        wheelFL.localRotation = Quaternion.Euler(0.0f, -90.0f + maxSteeringAngle * horizontalInput, 0.0f);
        wheelFR.localRotation = Quaternion.Euler(0.0f, 90.0f + maxSteeringAngle * horizontalInput, 0.0f);

        // rotate wheel forward/backwards
        wheelSpinAngle += (100.0f * Time.deltaTime * Vector3.Dot(rb.velocity, transform.forward));
        wheelFL.localRotation = Quaternion.Euler(0, wheelFL.localRotation.eulerAngles.y, wheelSpinAngle); // apply steering together
        wheelFR.localRotation = Quaternion.Euler(0, wheelFR.localRotation.eulerAngles.y, wheelSpinAngle); // apply steering together
        wheelRL.localRotation = Quaternion.Euler(0, -90, wheelSpinAngle);
        wheelRR.localRotation = Quaternion.Euler(0, 90, wheelSpinAngle);
        
        // move and rotate the car body
        rb.AddForce(transform.forward * forwardInput * forwardForce);
        if (rb.velocity.magnitude >= maxSpeed) // limit to max speed
        {
            rb.velocity = rb.velocity.normalized * maxSpeed;
        }
        rb.velocity *= (1 - speedReduceRate); // reduce the speed naturally

        transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime * horizontalInput);

        // add some downforce, keep the car on track
        rb.AddForce(-transform.up * downforce * rb.velocity.magnitude);
    }
}
