using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    bool movingRight;
    float moveRange = 3.0f;
    float moveSpeed = 2.0f;
    float initialXPosition;

    // Start is called before the first frame update
    void Start()
    {
        // randomly choose the enemy's initial direction
        if (Random.Range(0.0f, 1.0f) > 0.5f)
        { // start rightwards
            transform.eulerAngles = new Vector3(0, 90, 0);
            movingRight = true;
        } else { // start leftwards
            transform.eulerAngles = new Vector3(0, -90, 0);
            movingRight = false;
        }

        initialXPosition = transform.position.x;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime); // move forward

        if (movingRight)
        {
            if (transform.position.x >= initialXPosition + moveRange)
            {
                transform.eulerAngles = new Vector3(0, -90, 0);
                movingRight = false;
            }
        }
        else
        {
            if (transform.position.x <= initialXPosition - moveRange)
            {
                transform.eulerAngles = new Vector3(0, 90, 0);
                movingRight = true;
            }
        }
    }
}
