using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    private int totalCoins;  // Total number of coins in the scene
    private int collectedCoins;  // Number of coins collected by the player
    PlayerController playerController;
    DoorController doorController;
    public GameObject player;
    public GameObject bombPf;
    public ParticleSystem bombExplosionParticle;
    float bombSpawnInterval = 6.0f;
    float bombExplosionDelay = 3.0f;
    float bombExplosionDeathRange = 4.0f;
    Vector3[] bombSpawnPositions = {
        new Vector3(34, 5, 0),
        new Vector3(42, 6, 0),
        new Vector3(50, 7, 0),
        new Vector3(58, 8, 0)
    };
    private bool gameActive = true;
    private bool gameClear = false;

    // Start is called before the first frame update
    void Start()
    {
        totalCoins = GameObject.FindGameObjectsWithTag("Money").Length;
        collectedCoins = 0;

        playerController = player.GetComponent<PlayerController>();
        doorController = GameObject.Find("Door").GetComponent<DoorController>();

        InvokeRepeating("SpawnOddBombs", 1.0f, bombSpawnInterval);
        InvokeRepeating("SpawnEvenBombs", 1.0f + bombSpawnInterval / 2, bombSpawnInterval);
    }

    // Update is called once per frame
    void Update()
    {
        // *** when game is over or successfully cleared, user can restart the game by pressing R ***
        if ((!gameActive || gameClear) && Input.GetKeyDown(KeyCode.R))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }

    public void GameOver()
    {
        gameActive = false;
        playerController.PlayerDead();
    }

    public void GameClear()
    {
        gameClear = true;
    }

    // Call this method whenever a coin is collected
    public void CoinWasCollected()
    {
        collectedCoins++;

        // Check if all coins have been collected
        if (collectedCoins >= totalCoins)
        {
            doorController.OpenDoor();  // Trigger the wall to move up
        }
    }

    void SpawnOddBombs()
    {
        SpawnBomb(bombSpawnPositions[0]);
        SpawnBomb(bombSpawnPositions[2]);
    }

    void SpawnEvenBombs()
    {
        SpawnBomb(bombSpawnPositions[1]);
        SpawnBomb(bombSpawnPositions[3]);
    }

    void SpawnBomb(Vector3 spawnPosition)
    {
        // create bomb
        GameObject bomb = Instantiate(bombPf, spawnPosition, bombPf.transform.rotation);

        // wait for explosion
        StartCoroutine(WaitAndExplodeBomb(bomb));
    }

    IEnumerator WaitAndExplodeBomb(GameObject bomb)
    {
        // wait until explosion
        yield return new WaitForSeconds(bombExplosionDelay);

        // play explosion particles
        ParticleSystem explosionPs = Instantiate(bombExplosionParticle, bomb.transform.position, bomb.transform.rotation);
        explosionPs.Play();
        Destroy(explosionPs.gameObject, explosionPs.main.duration + 1.0f);

        // destroy bomb
        Destroy(bomb);

        // if player is near the explosion, player is dead
        if (Vector3.Distance(player.transform.position, bomb.transform.position) <= bombExplosionDeathRange)
        {
            GameOver();
        }
    }
}
