using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveStage4Plane : MonoBehaviour
{
    public bool initialMoveRight;  // setting differs per moving plane
    bool movingRight;
    float moveRange = 3.0f;
    float moveSpeed = 3.0f;
    float initialXPosition;

    // Start is called before the first frame update
    void Start()
    {
        if (initialMoveRight)
        { // start rightwards
            movingRight = true;
        }
        else
        { // start leftwards
            movingRight = false;
        }

        initialXPosition = transform.position.x;
    }

    // Update is called once per frame
    void Update()
    {
        if (movingRight)
        {
            transform.Translate(Vector3.right * moveSpeed * Time.deltaTime);

            if (transform.position.x >= initialXPosition + moveRange)
            {
                movingRight = false;
            }
        }
        else
        {
            transform.Translate(Vector3.left * moveSpeed * Time.deltaTime);

            if (transform.position.x <= initialXPosition - moveRange)
            {
                movingRight = true;
            }
        }
    }
}
