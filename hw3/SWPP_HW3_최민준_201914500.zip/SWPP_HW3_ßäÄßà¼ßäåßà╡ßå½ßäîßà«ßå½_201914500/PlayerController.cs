using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody playerRb;
    Animator playerAnimator;
    AudioSource playerAudio;
    public AudioClip jumpSound; // sound to play when jumping
    public AudioClip coinSound; // sound to play when eating coin
    public AudioClip finishSound;
    public ParticleSystem coinParticle;
    public ParticleSystem finishParticle;
    float moveForce = 1.25f;
    float jumpForce = 600.0f;
    float downforce = 200.0f;
    public float maxSpeed = 10.0f;
    public float minXPosition = -18.0f; // player cannot go left beyond this position
    float fixedZPosition; // player does not move along z-axis
    float steppedOnEnemyThreshold = 1.75f;
    GameObject steppedMovingPlane = null;
    Vector3 movingPlaneLastPosition;
    bool isGround = true; // whether the player is on ground
    public bool isAlive = true;
    GameManager gameManagerScript;

    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody>();
        playerAnimator = GetComponent<Animator>();
        playerAudio = GetComponent<AudioSource>();
        fixedZPosition = transform.position.z;
        gameManagerScript = GameObject.Find("GameManager").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        // Move the player based on left/right input
        float horizontalInput = Input.GetAxis("Horizontal");
        if (horizontalInput != 0 && isAlive)
        {
            // transform.Translate(Vector3.forward * Math.Abs(horizontalInput) * maxSpeed * Time.deltaTime);
            // playerRb.velocity = new Vector3(horizontalInput * maxSpeed, playerRb.velocity.y, 0);
            playerRb.AddForce(transform.forward * Math.Abs(horizontalInput) * moveForce, ForceMode.VelocityChange);

            if (horizontalInput > 0)
            {
                transform.eulerAngles = new Vector3(0, 90, 0);
            }
            else
            {
                transform.eulerAngles = new Vector3(0, -90, 0);
            }
            playerAnimator.SetFloat("Speed_f", 0.7f);
        }
        else
        {
            transform.eulerAngles = new Vector3(0, transform.eulerAngles.y, 0);
            playerAnimator.SetFloat("Speed_f", 0.0f);
        }

        if (playerRb.velocity.magnitude >= maxSpeed) // limit to max speed
        {
            playerRb.velocity = playerRb.velocity.normalized * maxSpeed;
        }

        if (Input.GetKeyDown(KeyCode.Space) && isGround && isAlive)
        {
            playerRb.AddForce(Vector3.up * jumpForce, ForceMode.Impulse); // jump!
            playerAnimator.SetBool("Jump_b", true);
            isGround = false;
            playerAudio.PlayOneShot(jumpSound);
        }
        else if (isGround || playerRb.velocity.y < -0.001f)
        { // if not jumping, the player cannot go up
            playerRb.AddForce(Vector3.down * downforce * playerRb.velocity.magnitude); // add some downforce
            float yVelocity = Math.Min(playerRb.velocity.y, 0.0f);
            playerRb.velocity = new Vector3(playerRb.velocity.x, yVelocity, playerRb.velocity.z);
        }
    }

    private void LateUpdate()
    {
        transform.position = new Vector3(Math.Max(transform.position.x, minXPosition), transform.position.y, fixedZPosition);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Ground") || collision.gameObject.CompareTag("MovingPlane"))
        { // if the player is on the ground
            isGround = true;
            playerAnimator.SetBool("Jump_b", false);
        }

        if (collision.gameObject.CompareTag("Money"))
        { // if collided with coin => particle, sound, coin disappears
            coinParticle.Play();
            playerAudio.PlayOneShot(coinSound);
            Destroy(collision.gameObject);
            gameManagerScript.CoinWasCollected();
        }

        if (collision.gameObject.CompareTag("Enemy"))
        { // if collided with enemy
            float collisionMinY = float.MaxValue;
            foreach (ContactPoint cp in collision.contacts)
            {
                if (cp.point.y < collisionMinY)
                {
                    collisionMinY = cp.point.y;
                }
            }

            if (collisionMinY > collision.gameObject.transform.position.y + steppedOnEnemyThreshold)
            { // if collided with the top of the enemy => enemy dies
                Destroy(collision.gameObject);
            }
            else
            { // if collided with the side of the enemy => game over
                gameManagerScript.GameOver();
            }
        }

        if (collision.gameObject.CompareTag("MovingPlane"))
        {
            steppedMovingPlane = collision.gameObject;
            movingPlaneLastPosition = steppedMovingPlane.transform.position;
        }

        if (collision.gameObject.CompareTag("Finish"))
        {
            playerAudio.PlayOneShot(finishSound);
            finishParticle.Play();
            Destroy(collision.gameObject);
            gameManagerScript.GameClear();
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("MovingPlane") && steppedMovingPlane != null)
        {
            Vector3 planePositionDelta = steppedMovingPlane.transform.position - movingPlaneLastPosition;
            transform.position += planePositionDelta;
            movingPlaneLastPosition = steppedMovingPlane.transform.position;
        }
    }

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.CompareTag("MovingPlane"))
        {
            steppedMovingPlane = null;
        }
    }

    public void PlayerDead()
    {
        isAlive = false;
        playerAnimator.SetBool("Death_b", true);
        playerAnimator.SetInteger("DeathType_int", 1);
    }
}
