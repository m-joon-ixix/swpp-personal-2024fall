using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    public float moveSpeed = 1.5f;
    public int maxHp;
    private int currentHp;
    private GameManager gameManager;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
        currentHp = maxHp;
    }

    // Update is called once per frame
    void Update()
    {
        if (gameManager.paused)
        {
            gameObject.GetComponent<Animator>().enabled = false;
        }
        else
        {
            gameObject.GetComponent<Animator>().enabled = true;

            transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
            if (transform.position.x > 15)
            {
                Destroy(gameObject);
            }
        }
    }

    private void OnCollisionEnter(Collision other)
    {
        if (other.gameObject.CompareTag("Projectile"))
        {
            currentHp -= 1;
            
            if (currentHp <= 0)
            {
                gameManager.EnemyKilled();
                Destroy(gameObject);
            }
        }

        if (other.gameObject.CompareTag("Goal"))
        {
            Destroy(other.gameObject);
            gameManager.GameOver();
        }
    }
}
