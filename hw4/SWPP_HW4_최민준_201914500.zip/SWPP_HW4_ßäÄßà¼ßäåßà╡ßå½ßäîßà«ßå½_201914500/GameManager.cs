using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    UIManager uiManager;
    public List<GameObject> enemyPfs;
    private GameObject currentPlayer;
    public GameObject normalPlayer;
    public GameObject upgradedPlayer;
    public GameObject goal;
    Quaternion enemyRotation = Quaternion.Euler(0, 90, 0);
    int stage = 1;
    int life = 1;
    int money = 0;
    int enemyCount;
    public bool started = false;
    public bool paused = false;
    public bool gameOver = false;

    // Start is called before the first frame update
    void Start()
    {
        uiManager = transform.Find("UIManager").GetComponent<UIManager>(); // UIManager object is under GameManager => transform.Find()        
        currentPlayer = normalPlayer;

        UpdateStatus();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void GoToNextStage()
    {
        if (stage == 3)
        {
            GameClear();
            return;
        }

        stage += 1;
        UpdateStatus();
        uiManager.SetStartButtonColor(false);
        started = false;
    }

    public void EnemyKilled()
    {
        money += 1;
        enemyCount -= 1;
        if (enemyCount <= 0)
        {
            GoToNextStage();
        }
        UpdateStatus();

        if (!gameOver && money >= 3)
        {
            uiManager.upgradeButton.gameObject.SetActive(true);
        }
    }

    public void GameOver()
    {
        life = 0;
        UpdateStatus();
        uiManager.ShowGameOver();
        gameOver = true;

        uiManager.SetStartButtonColor(false);
        uiManager.SetPauseButtonColor(false);

        currentPlayer.GetComponent<Animator>().enabled = false;
    }

    public void GameClear()
    {
        uiManager.ShowGameClear();
        gameOver = true;
    }

    void UpdateStatus()
    {
        uiManager.UpdateStatus(stage, life, money);
    }

    public void StartStage()
    {
        if (started) return;

        started = true;
        uiManager.SetStartButtonColor(true);
        SpawnEnemies();
        enemyCount = stage;
    }

    public void PauseGame()
    {
        if (gameOver) return;

        if (!paused)
        {
            paused = true;
            uiManager.SetPauseButtonColor(true);
            currentPlayer.GetComponent<Animator>().enabled = false;
            goal.GetComponent<Animator>().enabled = false;
        }
        else
        {
            paused = false;
            uiManager.SetPauseButtonColor(false);
            currentPlayer.GetComponent<Animator>().enabled = true;
            goal.GetComponent<Animator>().enabled = true;
        }
    }

    public void RestartGame()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); // load & restart the current scene!
    }

    public void UpgradePlayer()
    {
        if (gameOver) return;

        money -= 3;
        UpdateStatus();

        normalPlayer.SetActive(false);
        upgradedPlayer.SetActive(true);
        currentPlayer = upgradedPlayer; // reassign player

        uiManager.upgradeButton.gameObject.SetActive(false);
    }

    void SpawnEnemies()
    {
        for (int i = 0; i < stage; i++)
        {
            Instantiate(enemyPfs[stage - 1], EnemySpawnPosition(i), enemyRotation);
        }
    }

    private Vector3 EnemySpawnPosition(int index)
    {
        return new Vector3(-10 - 3 * index, 0, 0);
    }
}
