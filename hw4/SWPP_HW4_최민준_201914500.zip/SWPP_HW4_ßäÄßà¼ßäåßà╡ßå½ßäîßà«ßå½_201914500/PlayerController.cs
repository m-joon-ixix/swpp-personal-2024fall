using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public float throwRate;
    public GameObject projectilePf;
    private Vector3 projectileSpawnPosition = new Vector3(-0.2f, 1.0f, -4.5f);
    private Queue<GameObject> targetEnemies = new Queue<GameObject>();
    GameManager gameManager;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();        
        gameObject.GetComponent<Animator>().speed = throwRate;
        InvokeRepeating("ThrowProjectileToTargetEnemy", 0, 0.7f / throwRate); // throwing period is inversely proportional to throwRate
    }

    // Update is called once per frame
    void Update()
    {
        if (gameManager.gameOver)
        {
            CancelInvoke("ThrowProjectileToTargetEnemy");
        }
    }

    private void ThrowProjectileToTargetEnemy()
    {
        if (!gameManager.paused && targetEnemies.Count > 0)
        {
            GameObject targetEnemy = targetEnemies.Dequeue();
            transform.LookAt(targetEnemy.transform);

            transform.GetComponent<Animator>().SetTrigger("ThrowProjectile");
            StartCoroutine(InstantiateProjectile(targetEnemy));
        }
    }

    private IEnumerator InstantiateProjectile(GameObject targetEnemy)
    {
        yield return new WaitForSeconds(0.5f / throwRate);

        transform.LookAt(targetEnemy.transform);

        GameObject projectile = Instantiate(projectilePf, projectileSpawnPosition, transform.rotation);
        Vector3 targetEnemyPos = targetEnemy.transform.position;
        projectile.GetComponent<ProjectileController>().SetTargetPos(
            new Vector3(targetEnemyPos.x + 1.0f, targetEnemyPos.y, targetEnemyPos.z)
        );
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Enemy"))
        {
            EnemyController enemyController = other.gameObject.GetComponent<EnemyController>();
            for (int i = 0; i < enemyController.maxHp; i++)
            {
                targetEnemies.Enqueue(other.gameObject);
            }
        }
    }
}
