using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TitleCharacterController : MonoBehaviour
{
    private Animator animator;

    // Start is called before the first frame update
    void Start()
    {
        animator = gameObject.GetComponent<Animator>();

        if (gameObject.CompareTag("MainHuman")) MainHuman();
        else if (gameObject.CompareTag("ArmsCrossedHuman")) ArmsCrossedHuman();
        else if (gameObject.CompareTag("SittingHuman")) SittingHuman();
        else if (gameObject.CompareTag("Dog")) Dog();
        else if (gameObject.CompareTag("Cow")) Cow();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void MainHuman()
    {
        animator.SetInteger("Animation_int", 2); // hands on hips
    }

    private void ArmsCrossedHuman()
    {
        animator.SetInteger("Animation_int", 1);
    }

    private void SittingHuman()
    {
        animator.SetInteger("Animation_int", 9);
    }

    private void Dog()
    {
        animator.SetFloat("Speed_f", 0.0f);
        animator.SetBool("Bark_b", true);
    }

    private void Cow()
    {
        animator.SetFloat("Speed_f", 0.0f);
    }
}
