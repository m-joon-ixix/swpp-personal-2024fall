using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : MonoBehaviour
{
    GameManager gameManager;
    public TextMeshProUGUI gameOverText;
    public TextMeshProUGUI gameClearText;
    public TextMeshProUGUI statusText;
    public Button startButton;
    public Button pauseButton;
    public Button restartButton;
    public Button upgradeButton;

    // Start is called before the first frame update
    void Start()
    {
        gameManager = GameObject.Find("GameManager").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {

    }

    public void UpdateStatus(int _stage, int _life, int _money)
    {
        statusText.text = "Stage  : " + _stage + "\nLife     : " + _life + "\nMoney : " + _money;
    }

    public void SetStartButtonColor(bool on)
    {
        SetButtonColor(startButton, on);
    }

    public void SetPauseButtonColor(bool on)
    {
        SetButtonColor(pauseButton, on);
    }

    public void SetRestartButtonColor(bool on)
    {
        SetButtonColor(restartButton, on);
    }

    private void SetButtonColor(Button button, bool on)
    {
        if (on)
        {
            button.GetComponentInChildren<TextMeshProUGUI>().color = Color.red;
        }
        else
        {
            button.GetComponentInChildren<TextMeshProUGUI>().color = Color.black;
        }
    }

    public void ShowGameOver()
    {
        gameOverText.gameObject.SetActive(true);
    }

    public void ShowGameClear()
    {
        gameClearText.gameObject.SetActive(true);
    }
}
